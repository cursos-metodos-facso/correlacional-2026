# Plantilla de informe · Estadística Correlacional 2026

**Universidad de Chile · Departamento de Sociología**

Esta plantilla sirve para elaborar el trabajo grupal de **análisis bivariado con datos secundarios** en Quarto y R. Incluye la estructura del informe, carpetas organizadas y scripts vacíos para completar. **El informe no contiene análisis resueltos; solo incluye una figura ilustrativa basada en `mtcars`, disponible en R, que debes reemplazar antes de entregar.** La presentación utiliza la tipografía Fira Sans Condensed y el acento turquesa del sitio del curso; si no hay conexión, se usarán fuentes alternativas legibles.

La [pauta del trabajo](https://correlacional.metodos-facso.org/trabajos/trabajos.html) y las comunicaciones actualizadas del equipo docente determinan los requisitos definitivos.

## 1. Antes de comenzar

Necesitas **R**, **Quarto** y un editor como **Positron** o **RStudio**. Para ejecutar código R desde Quarto, instala el paquete `knitr` si no lo tienes. Instala otros paquetes de R únicamente si tu análisis los requiere.

1. Descarga y **descomprime toda la carpeta** del proyecto.
2. Abre la carpeta en Positron o RStudio (la raíz contiene `index.qmd`).
3. Conserva el nombre y la ubicación de las carpetas internas, o actualiza cuidadosamente sus rutas.

## 2. Organización de carpetas (IPO)

```text
estadistica-correlacional/
├── _quarto.yml               # Configuración HTML y formato visual
├── index.qmd                 # Informe principal: aquí escribes el texto
├── README.md                 # Instrucciones
├── .gitignore
├── input/
│   ├── data/
│   │   ├── original/         # Datos originales (no modificarlos)
│   │   └── proc/             # Datos preparados para el análisis
│   ├── images/                # Imágenes para insertar en el informe
│   └── bib/
│       ├── referencias.bib   # Fuentes bibliográficas del informe
│       └── apa.csl           # Estilo de referencias APA 7
├── processing/
│   ├── 01_preparacion.R      # Limpieza y recodificaciones
│   └── 02_analisis.R         # Tablas, pruebas y gráficos
├── output/
│   ├── graphs/               # Gráficos producidos
│   └── tables/               # Tablas producidas
└── libs/
    └── custom.scss          # Estilos visuales
```

**Input** = archivos de entrada; **Processing** = código para preparar y analizar; **Output** = resultados exportados. El HTML `index.html` aparece en la raíz al renderizar.

## 3. Cómo completar el informe

1. **Datos:** guarda la base de encuesta necesaria en `input/data/original/`. Consulta su cuestionario y libro de códigos. Para bases muy grandes, prepara y entrega un subconjunto reproducible; documenta el procedimiento que lo genera.
2. **Preparación:** edita `processing/01_preparacion.R` para seleccionar casos y variables, tratar códigos de no respuesta y guardar el archivo procesado en `input/data/proc/`. No sobrescribas los datos originales.
3. **Análisis:** edita `processing/02_analisis.R` para obtener descriptivos, análisis bivariados y medidas de asociación o efecto según tus hipótesis. Si exportas tablas o gráficos, usa `output/tables/` y `output/graphs/`.
4. **Redacción:** abre `index.qmd`, reemplaza todos los marcadores `[Completar: ...]` y actualiza el título, integrantes y fecha. Conserva el orden de las secciones, pero adapta los espacios para tablas y resultados a tu investigación. Al sustituir una indicación de escritura, elimina también las líneas `::: {.instruccion-plantilla}` y `:::` que la rodean para que tu texto tenga el estilo normal del informe. En el **Resumen**, conserva `::: {.resumen-plantilla}` y su cierre `:::`, pero sustituye la indicación por el resumen real, sin cursivas.
5. **Referencias:** el archivo `input/bib/referencias.bib` contiene una fuente real de ejemplo: `@wickham2023r`. En `index.qmd` verás cómo se cita y cómo Quarto genera automáticamente la entrada en Bibliografía en formato APA 7. Sustituye esa cita y entrada demostrativa por bibliografía pertinente a tu investigación; para otras fuentes, utiliza `@clave` o `[@clave]`.

La pauta pide **un concepto central, al menos dos variables explicativas y al menos tres hipótesis**, incluyendo como mínimo un cruce entre variables categóricas y otro entre una variable continua y una categórica. No todas las investigaciones requieren las mismas pruebas. Comprueba supuestos, valores perdidos y, si corresponde, ponderadores/diseño muestral.

## 4. Generar el archivo HTML

Desde una terminal situada en la carpeta raíz, ejecuta:

```bash
quarto render index.qmd
```

El **primer renderizado**, sin datos externos cargados, mostrará la estructura y la figura ilustrativa creada con `mtcars` (incluida en R). **No ejecutará tus scripts de análisis automáticamente**, porque el bloque inicial de `index.qmd` tiene `eval: false`.

Cuando hayas completado y probado ambos scripts R, cambia **solo** `#| eval: false` a `#| eval: true` en el bloque `procesamiento-reproducible` de `index.qmd`. De este modo, al renderizar se ejecutarán primero `01_preparacion.R` y `02_analisis.R`. Incorpora tus tablas y figuras al `.qmd` mediante código R, rutas relativas a los archivos exportados o ambos, y verifica que se muestren correctamente.

Si quieres ejecutar los scripts manualmente en R antes de renderizar, desde la raíz utiliza:

```r
source("processing/01_preparacion.R")
source("processing/02_analisis.R")
```

Un HTML con `embed-resources: true` se puede abrir de manera independiente, pero **el HTML por sí solo no permite repetir los análisis**. Para ello debes conservar el proyecto, los scripts y los datos utilizados.

## 5. Preparar la entrega en UCursos

Antes de comprimir, verifica lo siguiente:

- [ ] Reemplazaste los marcadores `[Completar: ...]`, los autores, el título y la fecha.
- [ ] Las hipótesis, variables, técnicas y resultados son coherentes entre secciones.
- [ ] Incluiste los análisis bivariados y las medidas solicitadas en la pauta.
- [ ] Documentaste N, valores perdidos, recodificaciones y decisiones metodológicas.
- [ ] Incorporaste las referencias bibliográficas reales.
- [ ] Ejecutaste `quarto render index.qmd` y revisaste el `index.html` generado.
- [ ] Verificaste que el informe se puede reproducir en una sesión limpia.
- [ ] El proyecto contiene `index.qmd`, `index.html`, los scripts, los datos utilizados y todos los archivos auxiliares necesarios.

Sustituye la figura ilustrativa `fig-ejemplo-descriptivo` por un gráfico realizado con tus propios datos. La pauta solicita el proyecto necesario para reproducir **tu propio informe**.

Comprime **la carpeta completa** y súbela a la tarea correspondiente de **UCursos**. No incluyas cachés, archivos temporales ni bases con información que no tengas autorización para compartir.

## 6. Recursos

- [Trabajo grupal del curso](https://correlacional.metodos-facso.org/trabajos/trabajos.html)
- [Documentación de Quarto](https://quarto.org/docs/)

- [Ejemplos de figuras en Quarto](https://quarto.org/docs/authoring/figures.html)
- [Referencias cruzadas de figuras y tablas](https://quarto.org/docs/authoring/cross-references.html)
