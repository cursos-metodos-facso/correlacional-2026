# ESTADÍSTICA CORRELACIONAL 2026 · ANÁLISIS BIVARIADO
# Completar desde la carpeta raíz del proyecto (donde está index.qmd).
# Elegir las técnicas según las hipótesis, los niveles de medición y supuestos.

# 1. Cargar la base procesada desde input/data/proc/

# 2. Estadísticos descriptivos: N, frecuencias, porcentajes,
#    medidas de tendencia central y dispersión según corresponda

# 3. Análisis bivariado entre variables categóricas
#    Tablas de contingencia, prueba de hipótesis y tamaño del efecto pertinente

# 4. Análisis bivariado entre variable continua y categórica
#    Elegir la técnica adecuada y reportar incertidumbre y tamaño del efecto

# 5. Exportar tablas a output/tables/ y gráficos a output/graphs/
#    Utilizar títulos, etiquetas y denominadores claros.

# Nota: si la encuesta tiene diseño complejo o requiere ponderaciones,
# adaptar los procedimientos antes de interpretar estimaciones poblacionales.
