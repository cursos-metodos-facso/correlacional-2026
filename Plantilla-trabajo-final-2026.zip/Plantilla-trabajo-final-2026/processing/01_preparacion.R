# ESTADÍSTICA CORRELACIONAL 2026 · PREPARACIÓN DE DATOS
# Completar desde la carpeta raíz del proyecto (donde está index.qmd).
# No modificar la base original. Utilizar rutas relativas.

# 1. Cargar los paquetes necesarios

# 2. Importar los datos desde input/data/original/
#    Identificar el formato real (p. ej., .csv, .rds, .dta, .RData).

# 3. Seleccionar las variables de interés y los casos pertinentes
#    Conservar un concepto central y al menos dos variables explicativas.

# 4. Revisar valores perdidos y códigos especiales de no respuesta
#    Documentar N original, criterios de exclusión y N analítico.

# 5. Recodificar y etiquetar las variables según el cuestionario
#    Justificar las transformaciones y respetar el nivel de medición.

# 6. Guardar la base procesada en input/data/proc/
#    Mantener intacto el archivo original.
